import logging

log = logging.getLogger("agent-core.antigravity")

class AntigravityTool:
    def run(self):
        log.info("Antigravity tool invoked")
        import antigravity  # importing triggers the effect
