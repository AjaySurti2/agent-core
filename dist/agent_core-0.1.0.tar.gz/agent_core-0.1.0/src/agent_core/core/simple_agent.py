import time
from agent_core.core.agent import Agent

class SimpleAgent(Agent):
    def step(self):
        self.logger.info("heartbeat")
        time.sleep(3)
        self.shutdown()
