import logging
from agent_core.config.logging import setup_logging
from agent_core.core.simple_agent import SimpleAgent

def main():
    setup_logging(level="INFO")

    logging.getLogger("bootstrap").info("main() entered")

    agent = SimpleAgent(name="agent-core")
    agent.run()

if __name__ == "__main__":
    main()

from agent_core.tools.antigravity_tool import AntigravityTool

tool = AntigravityTool()
tool.run()
